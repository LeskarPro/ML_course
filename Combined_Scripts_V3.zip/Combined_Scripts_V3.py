from mrdata import DimensionsConnector
import openpyxl
import xlsxwriter
import os

os.chdir(os.path.dirname(os.path.abspath(__file__)))

############# Switches #############

Create_Corr = True
Create_OE_Nets = True
clear_nets_in_excel = False

####################################

# UPDATE TAB_SPEC, codeframe, country and modules 
# No need for path update if Tab spec in Docs folder 

country_code = 'FR'
country = "France"
asked_modules = ["U", "C", "CH"]

file_path = f'DOCS' # From this folder we get Tabspec and Master brand list
tab_spec = 'DP Specs - Layout Standartization.xlsx'
code_frame_file = 'Master_Code_Frame_Lindt_JAN WAVE 2025_v21_28012025.xlsx'

mdd_file = f'2_Lindt_{country_code}_Recoded.mdd'
excell_file = f'OE_CODES_{country_code}.xlsx'
oe_nets_file = f'oe_nets_{country_code}.txt'
umbrella_nets_file = f'umbrella_nets_{country_code}.txt'


wb = openpyxl.load_workbook(file_path + "\\" + tab_spec)

# Preseting the corresponding columns
abs_row = 0

code_column = 1
brand_column = 2
name_to_apear_in_tabel_column = 3
dashboard_column = 5

# Work variables
wbs = []
nets_list = []
code_frame = []
module_labels = []

abs_value_per_module = {}
brands_per_module = {}
preselected_brands_per_module = {}
statements_per_module = {}

# Creating the dictionaries for the asked modules only 
for module in asked_modules:
    if module == "U":
        module_labels.append("UMBRELLA")
        brands_per_module["UMBRELLA"] = []
        preselected_brands_per_module["UMBRELLA"] = []
        statements_per_module["UMBRELLA"] = []
        abs_value_per_module["UMBRELLA"] = []
        
    elif module == "P":
        module_labels.append("PRALINES")
        brands_per_module["PRALINES"] = []
        preselected_brands_per_module["PRALINES"] = []
        statements_per_module["PRALINES"] = []
        abs_value_per_module["PRALINES"] = []

    elif module == "C":
        module_labels.append("BARS")
        brands_per_module["BARS"] = []
        preselected_brands_per_module["BARS"] = []
        statements_per_module["BARS"] = []
        abs_value_per_module["BARS"] = []

    elif module == "S":
        module_labels.append("SNACKING")
        brands_per_module["SNACKING"] = []
        preselected_brands_per_module["SNACKING"] = []
        statements_per_module["SNACKING"] = []
        abs_value_per_module["SNACKING"] = []
    
    elif module == "CH":
        module_labels.append("CHRISTMAS")
        brands_per_module["CHRISTMAS"] = []
        preselected_brands_per_module["CHRISTMAS"] = []
        statements_per_module["CHRISTMAS"] = []
        abs_value_per_module["CHRISTMAS"] = []
    
    elif module == "E":
        module_labels.append("EASTER")
        brands_per_module["EASTER"] = []
        preselected_brands_per_module["EASTER"] = []
        statements_per_module["EASTER"] = []
        abs_value_per_module["EASTER"] = []

    elif module == "V":
        module_labels.append("VALENTINES")
        brands_per_module["VALENTINES"] = []
        preselected_brands_per_module["VALENTINES"] = []
        statements_per_module["VALENTINES"] = []
        abs_value_per_module["VALENTINES"] = []

# Getting all the sheets having table specs in the name and sorting only the needed county 
for sheet_name in wb.sheetnames:
    if "modules" in sheet_name.lower():
        wbs.append(sheet_name)
print(wbs)

for ctry in wbs:
    if country.lower() in ctry.lower():
        sheet = wb[ctry]
        break

# Check section for the correct sheet and last row and column
print(sheet)
print(sheet.max_row)
print(sheet.max_column)

# Getting the starting and ending rows per module (I'll update for umbrela asked in the OE_Codes section instead of module section)
abs_row = 1
pr_module = ""
for module in module_labels:
    # We check for the module name per row in first column
    for row in range(abs_row, sheet.max_row + 1):
        if sheet.cell(row,code_column).value is not None and sheet.cell(row,code_column).value is not int():
            if module.lower() == "christmas": # Christmas is writen either XMAS or CHRISTMAS so here we check for both labels
                if module.lower() in str(sheet.cell(row,code_column).value).lower() or "xmas" in str(sheet.cell(row,code_column).value).lower():
                    abs_row = row + 1
                    abs_value_per_module[module].append(row)
                    if pr_module != "":
                        abs_value_per_module[pr_module].append(row-1)
                    break
            else:
                if module.lower() in str(sheet.cell(row,code_column).value).lower():
                    abs_row = row + 1
                    abs_value_per_module[module].append(row)
                    if pr_module != "":
                        abs_value_per_module[pr_module].append(row-1)
                    break
    pr_module = module
abs_value_per_module[pr_module].append(sheet.max_row)

#### OE_CODES SECTION ####

for row in range(1, sheet.max_row + 1):
    if "code" == str(sheet.cell(row,code_column).value).lower():
        abs_row = row + 1
        break
for row in range(abs_row, sheet.max_row + 1):   
    if sheet.cell(row,brand_column).value is None:
        break
    # if sheet.cell(row,code_column).value is None;
    nets_list.append([sheet.cell(row,code_column).value,sheet.cell(row,brand_column).value,sheet.cell(row,name_to_apear_in_tabel_column).value])

for i in range(len(nets_list)):
    if nets_list[i][0] is not None and not str(nets_list[i][0]).isdigit():
        nets_list[i][0] = nets_list[i][0].replace(u'\xa0', '')

# Cach the brand for each module
abs_row = 1
posotion = 1

for module in module_labels:

    # Here we set the starting position for the brand codes
    for row in range(abs_value_per_module[module][0], abs_value_per_module[module][1]):
        if sheet.cell(row,code_column).value is not None:
            if "code" in str(sheet.cell(row,code_column).value).lower():
                aba_first_row = row + 1
                abs_value_per_module[module][0] = row
                break
    
    # We write down in a dict the brands and the preselected brands per module in the definition section can be seen the dict structure for BRANDS_PER_MODULE and PRESELECTED_BRANDS_PER_MODULE
    #### ABA BRANDS SECTION ####
    for row in range(aba_first_row,abs_value_per_module[module][1] + 1):
        
        # Check for empty row to stop the iteration for the given module
        if sheet.cell(row,code_column).value is None or sheet.cell(row,code_column).value == "":
            aba_last_row = row - 1
            abs_row = row
            break
        elif row == abs_value_per_module[module][1]:
            aba_last_row = row
            abs_row = row
            break
        color=sheet.cell(row,brand_column).fill.start_color.index
        if color[2:] == "000000":
            color = "00FFFFFF"
        brands_per_module[module].append([sheet.cell(row,code_column).value, sheet.cell(row,brand_column).value, sheet.cell(row,name_to_apear_in_tabel_column).value, sheet.cell(row,dashboard_column).value,color[2:]])
        
        # For PRESELECTED_BRANDS_PER_MODULE we run a check for row NAME TO APPEAR IN THE TABLES BIA column to write down all the preselected brands
        if sheet.cell(row,code_column + 3).value is not None:
            color=sheet.cell(row,brand_column).fill.start_color.index
            if color[2:] == "000000":
                color = "00FFFFFF"
            preselected_brands_per_module[module].append([sheet.cell(row,code_column).value, sheet.cell(row,brand_column).value, sheet.cell(row,name_to_apear_in_tabel_column).value, sheet.cell(row,dashboard_column).value,color[2:]])

    #### BIA STATEMENTS SECTION ###
    for column in range(5, 15):
        row = abs_value_per_module[module][0]
        if 'bia' in str(sheet.cell(row,column).value).lower() or 'code' in str(sheet.cell(row,column).value).lower():
            bia_first_col = column
            if sheet.cell(abs_value_per_module[module][0] + 1,bia_first_col).value.isdigit():
                bia_first_row = abs_value_per_module[module][0] + 1
                break
            
    for row in range(bia_first_row,abs_value_per_module[module][1] + 1):
        if sheet.cell(row,bia_first_col).value is None or sheet.cell(row,bia_first_col).value == "":
            bia_last_row = row - 1
            abs_row = row
            break
        elif row == abs_value_per_module[module][1]:
            bia_last_row = row
            abs_row = row
            break
        color=sheet.cell(row,bia_first_col).fill.start_color.index
        if color[2:] == "000000":
            color = "00FFFFFF"
        statements_per_module[module].append([sheet.cell(row,bia_first_col).value, sheet.cell(row,bia_first_col + 1).value, sheet.cell(row,bia_first_col + 2).value,color[2:]])

    pr_module = module    

    # Check section for what codes and statements are we getting by row 
    print(module + ": \n" + "Brands: from row " + str(aba_first_row) + " to " + str(aba_last_row))
    print("Statements: from row " + str(bia_first_row) + " to " + str(bia_last_row))

wb.close()

if Create_Corr:
    # Creating th correspondence file
    workbook = xlsxwriter.Workbook('Analyses to Client/Correspondance File - ' + country + '.xlsx')
    ws_brands = workbook.add_worksheet('Brands_DA')
    ws_statements = workbook.add_worksheet('Statements_DA')

    #Preseting the format for the corr file
    module_format = workbook.add_format()
    module_format.set_font_name('Arial')
    module_format.set_align('center')
    module_format.set_align('vcenter')
    module_format.set_bold()
    module_format.set_border()
    module_format.set_font_color('white')
    module_format.set_font_size(14)
    module_format.set_bg_color('#305496')

    header_format = workbook.add_format()
    header_format.set_font_name('Arial')
    header_format.set_align('center')
    header_format.set_align('vcenter')
    header_format.set_bold()
    header_format.set_border()
    header_format.set_text_wrap()
    header_format.set_font_color('white')
    header_format.set_font_size(10)
    header_format.set_bg_color('#305496')

    awareness_image_format = workbook.add_format()
    awareness_image_format.set_font_name('Arial')
    awareness_image_format.set_bold()
    awareness_image_format.set_border()
    awareness_image_format.set_font_color('black')
    awareness_image_format.set_font_size(11)
    awareness_image_format.set_bg_color('#FFE699')

    ws_brands.set_column(1,1,22)
    ws_brands.set_column(2,2,11)
    ws_brands.set_column(3,6,35)

    ws_statements.set_column(1,1,25)
    ws_statements.set_column(2,3,60)

    #### ABA BRANDS SECTION ####
    # Start from the second cell for brands sheet. Rows and columns are zero indexed.
    row = 1
    col = 1

    # Iterate over the data and write it out row by row for Brands_DA sheet
    for module in brands_per_module.keys():

        # Header section for each module
        ws_brands.write(row, col, module, module_format)
        ws_brands.write(row, col + 1, 'INTERNAL Codes Xtrack', header_format)
        ws_brands.write(row, col + 2, 'BRAND NAME IN XTRACK', header_format)
        ws_brands.write(row, col + 3, 'CURRENT TABLES', header_format)
        ws_brands.write(row, col + 4, 'MARKET SUMMARY', header_format)
        ws_brands.write(row, col + 5, 'DASHBOARD', header_format)
        row+=2
        
        # Write down the Awareness brands
        ws_brands.merge_range(row, col, row, col + 5, "AWARENESS", awareness_image_format)
        row+=1
        for code, brand_name, name_to_apear_in_tabel, dashboard, color_fill in (brands_per_module[module]):
            brand_format = workbook.add_format()
            brand_format.set_font_name('Arial')
            brand_format.set_border()
            brand_format.set_font_size(10)
            color_fill = "#"+color_fill
            brand_format.set_bg_color(str(color_fill))
            ws_brands.write(row, col, '', brand_format)
            ws_brands.write(row, col + 1, code, brand_format)
            ws_brands.write(row, col + 2, brand_name, brand_format)
            ws_brands.write(row, col + 3, name_to_apear_in_tabel, brand_format)
            ws_brands.write(row, col + 4, '', brand_format)
            ws_brands.write(row, col + 5, dashboard, brand_format)
            row += 1
        
        # Write down the Image brands
        ws_brands.merge_range(row, col, row, col + 5, "IMAGE", awareness_image_format)
        row += 1
        for code, brand_name, name_to_apear_in_tabel, dashboard, color_fill in (preselected_brands_per_module[module]):
            brand_format = workbook.add_format()
            brand_format.set_font_name('Arial')
            brand_format.set_border()
            brand_format.set_font_size(10)
            color_fill = "#"+color_fill
            brand_format.set_bg_color(str(color_fill))
            ws_brands.write(row, col, '', brand_format)
            ws_brands.write(row, col + 1, code, brand_format)
            ws_brands.write(row, col + 2, brand_name, brand_format)
            ws_brands.write(row, col + 3, name_to_apear_in_tabel, brand_format)
            ws_brands.write(row, col + 4, '', brand_format)
            ws_brands.write(row, col + 5, dashboard, brand_format)
            row += 1
        row+=1

    #### BIA STATEMENTS SECTION ###
    # Start from the second cell for statements sheet. Rows and columns are zero indexed.
    row = 1
    col = 1

    # Iterate over the data and write it out row by row for Brands_DA sheet
    for module in statements_per_module.keys():

        # Header section for each module
        ws_statements.write(row, col, module, module_format)
        row += 1
        ws_statements.write(row, col, 'INTERNAL Codes Xtrack', header_format)
        ws_statements.write(row, col + 1, 'CURRENT TABLES', header_format)
        ws_statements.write(row, col + 2, 'DASHBOARD', header_format)
        row+=1
        
        for code, statement, dashboard, color_fill in (statements_per_module[module]):
            statements_format = workbook.add_format()
            statements_format.set_font_name('Arial')
            statements_format.set_border()
            statements_format.set_font_size(10)
            color_fill = "#"+color_fill
            statements_format.set_bg_color(str(color_fill))
            ws_statements.write(row, col, code, statements_format)
            ws_statements.write(row, col + 1, statement, statements_format)
            ws_statements.write(row, col + 2, dashboard, statements_format)
            row += 1
        row+=1
    workbook.close()

    # getting the codeframe list from excel
    cf = openpyxl.load_workbook(file_path + "\\" + code_frame_file)
    codes_sheet = cf['Sheet1']
    for row in range(1, codes_sheet.max_row + 1):
        if codes_sheet.cell(row,1).value is not None and not str(codes_sheet.cell(row,1).value).lower() == "level":
            code_frame.append([codes_sheet.cell(row,1).value, codes_sheet.cell(row,2).value, codes_sheet.cell(row,3).value])

######################################################### End of Corr file Section #########################################################

if Create_OE_Nets:

    # Creating the NEW_OE_CODES file from tabspec and code frame .xlsx
    oe_codes = xlsxwriter.Workbook(excell_file)
    codes = oe_codes.add_worksheet('Sheet1')
    brands = oe_codes.add_worksheet('Sheet2')

    #Preseting the format for the NEW_OE_CODES file
    codes.set_column(1,1,10)
    codes.set_column(2,2,35)

    brands.set_column(0,0,10)
    brands.set_column(1,2,40)


    header_format = oe_codes.add_format()
    header_format.set_font_name('Arial')
    header_format.set_border(2)
    header_format.set_bold()
    header_format.set_font_size(10)

    net_format = oe_codes.add_format()
    net_format.set_font_name('Arial')
    net_format.set_border()
    net_format.set_bold()
    net_format.set_font_size(10)

    code_frame_format = oe_codes.add_format()
    code_frame_format.set_font_name('Arial')
    code_frame_format.set_border()
    code_frame_format.set_font_size(10)

    umbrella_aba_format = oe_codes.add_format()
    umbrella_aba_format.set_font_name('Arial')
    umbrella_aba_format.set_bold()
    umbrella_aba_format.set_border(2)
    umbrella_aba_format.set_font_color('black')
    umbrella_aba_format.set_font_size(11)
    umbrella_aba_format.set_bg_color('#FFFF00')

    h1 = oe_codes.add_format()
    h1.set_font_name('Arial')
    h1.set_bold()
    h1.set_border()
    h1.set_font_color('red')
    h1.set_font_size(11)

    XXX = oe_codes.add_format()
    XXX.set_font_name('Arial')
    XXX.set_bold()
    XXX.set_border(1)
    XXX.set_font_color('black')
    XXX.set_font_size(11)


    # Creating Sheet1 with the code frame list
    row = 0

    codes.write(row, 0, 'Level', header_format)
    codes.write(row, 1, 'Output ID', header_format)
    codes.write(row, 2, 'Description', header_format)

    row += 1

    for i in code_frame:
        if i[1] == '':
            codes.write(row, 0, i[0], net_format)

            codes.write(row, 2, i[2], net_format)
        else:
            codes.write(row, 0, i[0], code_frame_format)
            codes.write(row, 1, i[1], code_frame_format)
            codes.write(row, 2, i[2], code_frame_format)
        row += 1

    # Creating Sheet2 with the oe codes from tab spec and brandcodes from tab spec list
    row = 1
    brands.merge_range(0, 0, 0, 2, "UMBRELLA", umbrella_aba_format)
    brands.write(row, 0, "Code", h1)
    brands.write(row, 1, "Brand", h1)
    brands.write(row, 2, "NAME TO APPEAR IN THE TABLES", h1)
    row += 1
    for i in nets_list: # First part with the oe_nest
        if i[0] is None or i[0] == '':
            brands.write(row, 0, i[0], net_format)
            brands.write(row, 1, i[1], net_format)
            brands.write(row, 2, i[2], net_format)
        else:
            brands.write(row, 0, i[0], code_frame_format)
            brands.write(row, 1, i[1], code_frame_format)
            brands.write(row, 2, i[2], code_frame_format)
        row += 1

    # Second part with ABA codes and brands
    brands.merge_range(row, 0, row, 2, "ABA", umbrella_aba_format)
    row += 1
    brands.write(row, 0, "Code", h1)
    brands.write(row, 1, "Brand", h1)
    brands.write(row, 2, "NAME TO APPEAR IN THE TABLES", h1)
    row += 1

    for module in brands_per_module.keys():
        for i in brands_per_module[module]:
            brands.write(row, 0, i[0], code_frame_format)
            brands.write(row, 1, i[1], code_frame_format)
            brands.write(row, 2, i[2], code_frame_format)
            row += 1
    brands.write(row, 0, "XXX", XXX)

    oe_codes.close()

    ######################################################### End of OE Nets file Section #########################################################

    #EXCEL FILES
    wb = openpyxl.load_workbook(excell_file)
    sh1 = wb['Sheet1']
    level_sheet_1, code_sheet_1, brand_sheet_1 = 1, 2, 3
    sh2 = wb['Sheet2']
    code_sheet_2, brand_sheet_2, rename_brand_sheet_2 = 1, 2, 3

    dict_nets = {} # names:net_codes - brands sheet 1
    dict_nets_umbrella = {} # net_codes:names - umbrella brands sheet 2
    dict_map_umbrella = {} # net_codes:codes - umbrella brands sheet 2
    dict_relabel_brands = {} # codes:names - module brands sheet 2

    #CLEAR NETS - SHEET 1 AND 2
    if clear_nets_in_excel == True:
        for row in range(2,sh1.max_row + 1):
            try:
                if sh1.cell(row,code_sheet_1).value[0] == "n": sh1.cell(row,code_sheet_1).value = None
            except:
                TypeError

        for row in range(2,sh2.max_row + 1):
            try:
                if sh2.cell(row,code_sheet_2).value[0] == "n": sh2.cell(row,code_sheet_2).value = None
            except:
                TypeError

    #fill - dict_nets
    net_number = 1 # for new nets in sheet 1
    for row in range(2,sh1.max_row + 1):
        if sh1.cell(row,code_sheet_1).value is None:
            sh1.cell(row,code_sheet_1).value = "n"+str(net_number)
            net_number += 1
        try:
            if sh1.cell(row,code_sheet_1).value[0] == "n":
                code = sh1.cell(row,code_sheet_1).value.strip()
                brand = sh1.cell(row,brand_sheet_1).value.upper().strip()
                dict_nets[brand] = code
        except:
            TypeError

    #FILL NETS IN SHEET 2 AND PRINT MISSING CODES FROM dict_nets
    for row in range(2,sh2.max_row + 1):
        if sh2.cell(row,code_sheet_2).value == "ABA": break
        if sh2.cell(row,code_sheet_2).value is None:
            brand = sh2.cell(row,brand_sheet_2).value.upper().strip()
            if brand in dict_nets: sh2.cell(row,code_sheet_2).value = dict_nets[brand]
            if sh2.cell(row,code_sheet_2).value is None: print(f"Brand {sh2.cell(row,brand_sheet_2).value} not found in Sheet1")

    #fill - dict_nets_umbrella
    for row in range(3,sh2.max_row + 1):
        if sh2.cell(row,code_sheet_2).value == "ABA": break
        code = sh2.cell(row,code_sheet_2).value
        brand = sh2.cell(row,rename_brand_sheet_2).value.strip().replace("'","''")
        dict_nets_umbrella[code] = brand

    #fill - dict_map_umbrella
    for row in range(3,sh2.max_row + 1,2):
        aba_row = row + 2
        if sh2.cell(row,code_sheet_2).value == "ABA": break
        net_ = sh2.cell(row,code_sheet_2).value
        code_ = sh2.cell(row + 1,code_sheet_2).value
        dict_map_umbrella[net_] = code_

    #fill - dict_relabel_brands
    for row in range(aba_row,sh2.max_row + 1):
        if sh2.cell(row,code_sheet_2).value == "XXX": break
        brand = sh2.cell(row,rename_brand_sheet_2).value.strip()
        code = "_" + str(sh2.cell(row,code_sheet_2).value)
        dict_relabel_brands[code] = brand

    #WRITE OE NETS FILE
    list_net = []
    curr_level, prev_level = 0, 0

    with open(oe_nets_file,'w', encoding="utf-16") as f:
        f.write('OE_nets = "_\n')
        for row in range(2,sh1.max_row + 1):
            if sh1.cell(row,level_sheet_1).value == None: break
            curr_level = sh1.cell(row,level_sheet_1).value
            curr_code = sh1.cell(row,code_sheet_1).value
            curr_brand = sh1.cell(row,brand_sheet_1).value.replace("'","''")

            if str(curr_code)[0] == "n":
                if curr_code in dict_nets_umbrella: text_ = f"_{curr_code} '{dict_nets_umbrella[curr_code]}'" + " net({"
                else:                               text_ = f"_{curr_code} '{curr_brand}'" + " net({"
            else:
                if curr_code in dict_nets_umbrella: text_ = f"_{curr_code} '{dict_nets_umbrella[curr_code]}'"
                else:                               text_ = f"_{curr_code}"
            list_net.append(text_)

            if curr_level < prev_level: #exit net
                str_net = ""
                for i in range(len(list_net)):
                    if list_net[i][1] == "n":
                        f.write(str_net+"_\n") #new line for nets in the list
                        str_net = list_net[i]
                    else:
                        str_net += list_net[i] + ","

                f.write(str_net[:-1] + "})"*(prev_level - curr_level) + ",") #calculate brackets
                list_net = [list_net[-1]] #collect last entry
            prev_level = curr_level

        #write last entry in the txt file
        str_net = "" 
        for i in range(len(list_net) - 1):
            if list_net[i][1] == "n":
                f.write(str_net+"_\n") #new line for nets in the list
                str_net = list_net[i]
            else:
                str_net += list_net[i] + ","

        f.write(str_net[:-1] + "})"* (prev_level - curr_level)) #calculate brackets
        f.write('"')


    #WRITE UMBRELLA NETS FILE
    with open(umbrella_nets_file,'w', encoding="utf-16") as f:
        for key_net in dict_map_umbrella: 
            for row in range(1,sh1.max_row + 1):
                if sh1.cell(row,code_sheet_1).value == key_net:
                    list_net = []
                    curr_level, prev_level = 0, 0
                    net_row = row + 1
                    net_level = sh1.cell(row,level_sheet_1).value
            
                    for inner_row in range(net_row,sh1.max_row + 1):
                        if sh1.cell(inner_row,level_sheet_1).value <= net_level: break
                        
                        curr_level = sh1.cell(inner_row,level_sheet_1).value
                        curr_code = sh1.cell(inner_row,code_sheet_1).value

                        if str(curr_code)[0] != "n": list_net.append(f"_{curr_code}")
                        prev_level = curr_level

                    str_net = ",".join(str(item) for item in list_net if item[1] != "n")
                    f.write(f"'''{dict_nets_umbrella[key_net]}\n")
                    f.write(f'd_brands.Add("_{dict_map_umbrella[key_net]}","{str_net}")\n')
                    break
            f.write(f"\n")

    wb.save(excell_file)

    #RELABEL BRANDS IN MDD
    mdm = DimensionsConnector.MDM(mdd_file, 2)

    list_types = '''
    BRANDLIST_LOGOS,
    BRANDLIST_CLOSENESS,
    BRANDLIST_TEXT_ONLY,
    pre_selected_brands_LOGOS,
    pre_selected_brands_TEXT_ONLY
    '''

    for mdd_list in list_types.split(","):
        mdd_list = str(mdd_list).strip()
        for mdd_brand in mdm.Types[mdd_list].Elements:
            if mdd_brand.Name in dict_relabel_brands:
                mdm.Types[mdd_list].Elements[mdd_brand.Name].Label = dict_relabel_brands[mdd_brand.Name]

    mdm.Save()
    mdm.Close()